
import java.util.Scanner;

public class BatallaNaval {
    static final int TAM = 5;
    static final char AGUA = '~';
    static final char BARCO = 'B';
    static final char TOCADO = 'X';
    static final char FALLO = 'O';

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        char[][] tablero1 = new char[TAM][TAM];
        char[][] disparos1 = new char[TAM][TAM];
        char[][] tablero2 = new char[TAM][TAM];
        char[][] disparos2 = new char[TAM][TAM];

        inicializar(tablero1);
        inicializar(disparos1);
        inicializar(tablero2);
        inicializar(disparos2);

        System.out.println("Jugador 1, coloca tus barcos:");
        colocarBarcos(tablero1, sc);

        System.out.println("Jugador 2, coloca tus barcos:");
        colocarBarcos(tablero2, sc);

        int turno = 1;
        while (hayBarcos(tablero1) && hayBarcos(tablero2)) {
            System.out.println("Turno del Jugador " + turno);
            if (turno == 1) {
                jugar(tablero2, disparos1, sc);
                turno = 2;
            } else {
                jugar(tablero1, disparos2, sc);
                turno = 1;
            }
        }

        System.out.println("Juego terminado.");
        if (hayBarcos(tablero1)) {
            System.out.println("Jugador 1 gana.");
        } else {
            System.out.println("Jugador 2 gana.");
        }

        sc.close();
    }

    static void inicializar(char[][] t) {
        for (int i = 0; i < TAM; i++)
            for (int j = 0; j < TAM; j++)
                t[i][j] = AGUA;
    }

    static void colocarBarcos(char[][] t, Scanner sc) {
        int[] tamanos = {3, 3, 3, 2};
        for (int tam : tamanos) {
            boolean colocado = false;
            while (!colocado) {
                System.out.println("Coloca barco de tamaño " + tam);
                System.out.print("Fila inicial (0-" + (TAM - 1) + "): ");
                int f = sc.nextInt();
                System.out.print("Columna inicial (0-" + (TAM - 1) + "): ");
                int c = sc.nextInt();
                System.out.print("Orientación (H para horizontal, V para vertical): ");
                char dir = sc.next().toUpperCase().charAt(0);

                if (dir == 'H') {
                    if (c + tam <= TAM && f < TAM) {
                        boolean libre = true;
                        for (int i = 0; i < tam; i++) {
                            if (t[f][c + i] == BARCO) libre = false;
                        }
                        if (libre) {
                            for (int i = 0; i < tam; i++) t[f][c + i] = BARCO;
                            colocado = true;
                        } else {
                            System.out.println("Ya hay un barco en esa posición.");
                        }
                    } else {
                        System.out.println("Posición inválida.");
                    }
                } else if (dir == 'V') {
                    if (f + tam <= TAM && c < TAM) {
                        boolean libre = true;
                        for (int i = 0; i < tam; i++) {
                            if (t[f + i][c] == BARCO) libre = false;
                        }
                        if (libre) {
                            for (int i = 0; i < tam; i++) t[f + i][c] = BARCO;
                            colocado = true;
                        } else {
                            System.out.println("Ya hay un barco en esa posición.");
                        }
                    } else {
                        System.out.println("Posición inválida.");
                    }
                } else {
                    System.out.println("Orientación no válida.");
                }
            }
        }
    }

    static void jugar(char[][] enemigo, char[][] disparos, Scanner sc) {
        mostrar(disparos);
        System.out.print("Fila a disparar (0-4): ");
        int f = sc.nextInt();
        System.out.print("Columna a disparar (0-4): ");
        int c = sc.nextInt();

        if (f < 0 || f >= TAM || c < 0 || c >= TAM) {
            System.out.println("Coordenadas fuera del tablero.");
            return;
        }

        if (disparos[f][c] == TOCADO || disparos[f][c] == FALLO) {
            System.out.println("Ya disparaste en esa posición.");
            return;
        }

        if (enemigo[f][c] == BARCO) {
            System.out.println("Tocado.");
            disparos[f][c] = TOCADO;
            enemigo[f][c] = TOCADO;
        } else {
            System.out.println("Fallaste.");
            disparos[f][c] = FALLO;
        }
    }

    static void mostrar(char[][] t) {
        System.out.println("  0 1 2 3 4");
        for (int i = 0; i < TAM; i++) {
            System.out.print(i + " ");
            for (int j = 0; j < TAM; j++) {
                System.out.print(t[i][j] + " ");
            }
            System.out.println();
        }
    }

    static boolean hayBarcos(char[][] t) {
        for (int i = 0; i < TAM; i++)
            for (int j = 0; j < TAM; j++)
                if (t[i][j] == BARCO)
                    return true;
        return false;
    }
}

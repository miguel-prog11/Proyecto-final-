import java.util.Scanner;

public class BatallaNavalMain {
    public static void main(String[] args) {
        Juego juego = new Juego();
        juego.iniciar();
    }
}
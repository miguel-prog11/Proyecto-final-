class Barco {
    int fila, columna, tamano;
    char direccion;

    public Barco(int fila, int columna, int tamano, char direccion) {
        this.fila = fila;
        this.columna = columna;
        this.tamano = tamano;
        this.direccion = direccion;
    }

    public boolean esValido(int limite) {
        if (direccion != 'H' && direccion != 'V') return false;
        if (fila < 0 || columna < 0) return false;

        if (direccion == 'H') return columna + tamano <= limite && fila < limite;
        else return fila + tamano <= limite && columna < limite;
    }
}
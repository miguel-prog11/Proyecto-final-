class Tablero {
    private static final int TAM = 5;
    private static final char AGUA = '~';
    private static final char BARCO = 'B';
    private static final char TOCADO = 'X';
    private static final char FALLO = 'O';

    private char[][] propio;
    private boolean[][] disparos;

    public Tablero() {
        propio = new char[TAM][TAM];
        disparos = new boolean[TAM][TAM];
        for (int i = 0; i < TAM; i++)
            for (int j = 0; j < TAM; j++)
                propio[i][j] = AGUA;
    }

    public boolean colocarBarco(Barco b) {
        if (!b.esValido(TAM)) return false;

        for (int i = 0; i < b.tamano; i++) {
            int f = b.fila + (b.direccion == 'V' ? i : 0);
            int c = b.columna + (b.direccion == 'H' ? i : 0);
            if (propio[f][c] == BARCO) return false;
        }

        for (int i = 0; i < b.tamano; i++) {
            int f = b.fila + (b.direccion == 'V' ? i : 0);
            int c = b.columna + (b.direccion == 'H' ? i : 0);
            propio[f][c] = BARCO;
        }
        return true;
    }

    public boolean disparar(int fila, int col) {
        if (fila < 0 || fila >= TAM || col < 0 || col >= TAM) {
            System.out.println("Fuera del tablero.");
            return false;
        }
        if (disparos[fila][col]) {
            System.out.println("Ya atacaste esa posición.");
            return false;
        }

        disparos[fila][col] = true;
        if (propio[fila][col] == BARCO) {
            propio[fila][col] = TOCADO;
            System.out.println("¡Tocado!");
        } else {
            propio[fila][col] = FALLO;
            System.out.println("Fallaste.");
        }
        return true;
    }

    public void mostrarOculto() {
        System.out.println("Tablero del oponente:");
        mostrar(true);
    }

    public void mostrarPropio() {
        System.out.println("Tu tablero:");
        mostrar(false);
    }

    private void mostrar(boolean oculto) {
        System.out.println("  0 1 2 3 4");
        for (int i = 0; i < TAM; i++) {
            System.out.print(i + " ");
            for (int j = 0; j < TAM; j++) {
                char c = propio[i][j];
                if (oculto && c == BARCO) {
                    System.out.print(AGUA + " ");
                } else {
                    System.out.print(c + " ");
                }
            }
            System.out.println();
        }
    }

    public boolean quedanBarcos() {
        for (int i = 0; i < TAM; i++)
            for (int j = 0; j < TAM; j++)
                if (propio[i][j] == BARCO)
                    return true;
        return false;
    }
}
import java.util.Scanner;

class Juego {
    private Jugador jugador1;
    private Jugador jugador2;
    private Scanner sc = new Scanner(System.in);

    public void iniciar() {
        System.out.println("=== Batalla Naval ===");
        jugador1 = new Jugador("Jugador 1", sc);
        jugador2 = new Jugador("Jugador 2", sc);

        jugador1.colocarBarcos();
        jugador2.colocarBarcos();

        while (jugador1.tieneBarcos() && jugador2.tieneBarcos()) {
            turno(jugador1, jugador2);
            if (jugador2.tieneBarcos()) {
                turno(jugador2, jugador1);
            }
        }

        if (jugador1.tieneBarcos()) {
            System.out.println("¡" + jugador1.getNombre() + " gana!");
        } else {
            System.out.println("¡" + jugador2.getNombre() + " gana!");
        }
    }

    private void turno(Jugador atacante, Jugador defensor) {
        System.out.println("Turno de " + atacante.getNombre());
        defensor.getTablero().mostrarOculto();
        atacante.getTablero().mostrarPropio();

        int fila, col;
        do {
            System.out.print("Fila a disparar (0-4): ");
            fila = sc.nextInt();
            System.out.print("Columna a disparar (0-4): ");
            col = sc.nextInt();
        } while (!defensor.getTablero().disparar(fila, col));
    }
}
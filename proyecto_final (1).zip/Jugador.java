import java.util.Scanner;

class Jugador {
    private String nombre;
    private Tablero tablero;
    private Scanner sc;

    public Jugador(String nombre, Scanner sc) {
        this.nombre = nombre;
        this.sc = sc;
        tablero = new Tablero();
    }

    public void colocarBarcos() {
        System.out.println(nombre + ", coloca tus barcos.");
        int[] tamanos = {3, 3, 3, 2};
        for (int tam : tamanos) {
            boolean colocado = false;
            while (!colocado) {
                System.out.println("Coloca barco de tamaño " + tam);
                System.out.print("Fila inicial: ");
                int f = sc.nextInt();
                System.out.print("Columna inicial: ");
                int c = sc.nextInt();
                System.out.print("Orientación (H/V): ");
                char dir = sc.next().toUpperCase().charAt(0);
                colocado = tablero.colocarBarco(new Barco(f, c, tam, dir));
                if (!colocado) System.out.println("Ubicación inválida, intenta otra vez.");
            }
        }
    }

    public boolean tieneBarcos() {
        return tablero.quedanBarcos();
    }

    public Tablero getTablero() {
        return tablero;
    }

    public String getNombre() {
        return nombre;
    }
}